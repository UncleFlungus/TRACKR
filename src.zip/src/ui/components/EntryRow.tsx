import { getFieldType, isFieldEmpty } from '@/core/fields';
import type { Entry, Field } from '@/core/types';

interface Props {
  entry: Entry;
  fields: Field[];
  /** If true, hide fields whose value is empty for this entry. Default: true. */
  hideEmpty?: boolean;
  onClick: () => void;
}

export default function EntryRow({ entry, fields, hideEmpty = true, onClick }: Props) {
  const visibleFields = hideEmpty
    ? fields.filter((f) => {
        const def = getFieldType(f.type);
        return !isFieldEmpty(def, entry.values[f.id], f.config);
      })
    : fields;

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white border border-grape-100 rounded-xl px-4 py-3 hover:border-grape-300 hover:bg-grape-50/30 transition-colors cursor-pointer"
    >
      {visibleFields.length === 0 ? (
        <p className="text-grape-300 text-[13px] italic">No values yet — tap to edit</p>
      ) : (
        <div className="space-y-1.5">
          {visibleFields.map((field) => {
            const def = getFieldType(field.type);
            return (
              <div key={field.id} className="flex items-baseline gap-3">
                <span className="text-grape-400 text-[11px] font-semibold uppercase tracking-wide w-24 shrink-0">
                  {field.name}
                </span>
                <div className="flex-1 min-w-0 truncate">
                  <def.Display
                    value={entry.values[field.id] as any}
                    config={field.config as any}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
      <p className="text-grape-300 text-[11px] mt-2">
        {new Date(entry.createdAt).toLocaleString()}
      </p>
    </button>
  );
}