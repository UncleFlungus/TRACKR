import { Check, Square } from 'lucide-react';
import type { FieldTypeDef } from '../types';

interface CheckmarkConfig {
  // Empty for now — could grow to include "labels" (Done/Not done, Yes/No)
  // or "default to checked" if useful later.
}

/**
 * Checkbox field stored as a boolean. Useful for to-do lists,
 * "completed?" markers, yes/no flags, etc.
 *
 * Stored as: true | false | null. Null means "never set" (treated as unchecked
 * for filtering but visually distinct from explicit false if we ever want it).
 */
export const checkmarkField: FieldTypeDef<CheckmarkConfig, boolean> = {
  id: 'checkmark',
  label: 'Checkmark',
  icon: 'CheckSquare',
  defaultConfig: {},
  defaultValue: false,
  validate: (value) => {
    if (value == null) return null;
    if (typeof value !== 'boolean') return 'Must be a checkmark';
    return null;
  },
  Input: ({ value, onChange }) => (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className="flex items-center gap-2 py-2 text-grape-700 hover:text-grape-900 transition-colors"
    >
      {value ? (
        <span className="w-5 h-5 rounded-md bg-grape-500 text-white flex items-center justify-center">
          <Check className="w-3.5 h-3.5" strokeWidth={3} />
        </span>
      ) : (
        <span className="w-5 h-5 rounded-md border-2 border-grape-300 hover:border-grape-500 transition-colors" />
      )}
      <span className="text-[14px]">{value ? 'Done' : 'Not done'}</span>
    </button>
  ),
  Display: ({ value }) =>
    value ? (
      <span className="inline-flex items-center gap-1.5 text-grape-700 text-[14px]">
        <span className="w-4 h-4 rounded bg-grape-500 text-white flex items-center justify-center">
          <Check className="w-3 h-3" strokeWidth={3} />
        </span>
        Done
      </span>
    ) : (
      <span className="inline-flex items-center gap-1.5 text-grape-400 text-[14px]">
        <Square className="w-4 h-4" />
        Not done
      </span>
    ),
};